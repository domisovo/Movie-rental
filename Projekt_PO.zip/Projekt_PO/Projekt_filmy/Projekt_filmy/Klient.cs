﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Projekt_filmy
{
    public class WrongKlientException : Exception
    {
        public WrongKlientException(string message) : base(message) { }
    }
    public abstract class KlientBase
    {
        public abstract void PobierzInformacje();
    }

    //Interfejs
    public interface IKlientOperacje
    {
        void WypożyczFilm();
        void ZwróćFilm();
        void SprawdźHistorięWypożyczeń();
        abstract void PobierzInformacje();
    }

    // Klasa Klient
    public class Klient : KlientBase, IComparable<Klient>, IKlientOperacje
    {
        public int iD;
        public static int licznik;
        public string imię;
        public string nazwisko;
        public string adres;
        public string email;
        public string numerTelefonu;

        public int ID { get; set; }
        public string Imię { get; set; }
        public string Nazwisko { get; set; }
        public string Adres { get; set; }
        public string Email
        {
            get { return email; }
            set
            {
                string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
                if (!Regex.IsMatch(value, pattern))
                {
                    throw new WrongKlientException("Nieprawidłowy adres e-mail.");
                }
                email = value;
            }
        }
        public string NumerTelefonu
        {
            get { return numerTelefonu; }
            set
            {
                if (value.Length != 9 || !int.TryParse(value, out _))
                {
                    throw new WrongKlientException("Nieprawidłowy numer telefonu. Numer powinien składać się z dokładnie 9 cyfr.");
                }
                numerTelefonu = value;
            }
        }

       
        static Klient()
        {
            licznik = 1;
        }
        public Klient() 
        {
            ID = licznik;
            licznik++;
        } 
        public Klient(string imię, string nazwisko, string adres, string email, string numerTelefonu) : this()
        {
            Imię = imię;
            Nazwisko = nazwisko;
            Adres = adres;
            Email = email;
            NumerTelefonu = numerTelefonu;
        }
        public void WypożyczFilm()
        {
            Console.WriteLine("Film został wypożyczony klientowi.");
        }

        public void ZwróćFilm()
        {
            Console.WriteLine("Film został zwrócony przez klienta.");
        }

        public void SprawdźHistorięWypożyczeń()
        {
            Console.WriteLine("Historia wypożyczeń klienta.");
        }

        public override void PobierzInformacje()
        {
            Console.WriteLine($"ID: {ID},{Imię} {Nazwisko}, Adres: {Adres}, Email: {Email}, Numer telefonu: {NumerTelefonu}");
        }

        public int CompareTo(Klient? other)
        {
            if (other == null) { return -1; }
            int cmp = Nazwisko.CompareTo(other.Nazwisko);
            if (cmp != 0) { return cmp; }
            return Imię.CompareTo(other.Imię);
        }
        public override string ToString()
        {
            return $"ID: {ID}, {Imię} {Nazwisko}, Adres: {Adres}, Email: {Email}, Numer telefonu: {NumerTelefonu}";
        }
    
    }

}
