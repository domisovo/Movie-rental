﻿using Projekt_filmy;
public class Program : BazaDanych
{
    static void Proba()
    {
        // Inicjalizacja bazy danych
        BazaDanych baza = new BazaDanych();

        // Dodanie kilku filmów
        baza.DodajFilm(new Film { ID = 1, Tytuł = "Pulp Fiction", Reżyser = "Quentin Tarantino", RokProdukcji = 1994, Gatunek = "Crime", CzasTrwania = 154, Ocena = 8.9 });
        baza.DodajFilm(new Film { ID = 2, Tytuł = "Stalker", Reżyser = "Andrei Tarkovsky", RokProdukcji = 1979, Gatunek = "Sci-Fi", CzasTrwania = 163, Ocena = 8.1 });
        baza.DodajFilm(new Film { ID = 3, Tytuł = "The Shawshank Redemption", Reżyser = "Frank Darabont", RokProdukcji = 1994, Gatunek = "Drama", CzasTrwania = 142, Ocena = 9.3 });
        baza.DodajFilm(new Film { ID = 4, Tytuł = "The Godfather", Reżyser = "Francis Ford Coppola", RokProdukcji = 1972, Gatunek = "Crime", CzasTrwania = 175, Ocena = 9.2 });
        baza.DodajFilm(new Film { ID = 5, Tytuł = "The Dark Knight", Reżyser = "Christopher Nolan", RokProdukcji = 2008, Gatunek = "Action", CzasTrwania = 152, Ocena = 9.0 });
        baza.DodajFilm(new Film { ID = 6, Tytuł = "Forrest Gump", Reżyser = "Robert Zemeckis", RokProdukcji = 1994, Gatunek = "Drama", CzasTrwania = 142, Ocena = 8.8 });
        baza.DodajFilm(new Film { ID = 7, Tytuł = "Inception", Reżyser = "Christopher Nolan", RokProdukcji = 2010, Gatunek = "Sci-Fi", CzasTrwania = 148, Ocena = 8.7 });
        baza.DodajFilm(new Film { ID = 8, Tytuł = "The Matrix", Reżyser = "The Wachowskis", RokProdukcji = 1999, Gatunek = "Action", CzasTrwania = 136, Ocena = 8.7 });
        baza.DodajFilm(new Film { ID = 9, Tytuł = "Schindler's List", Reżyser = "Steven Spielberg", RokProdukcji = 1993, Gatunek = "Biography", CzasTrwania = 195, Ocena = 8.9 });
        baza.DodajFilm(new Film { ID = 10, Tytuł = "The Silence of the Lambs", Reżyser = "Jonathan Demme", RokProdukcji = 1991, Gatunek = "Crime", CzasTrwania = 118, Ocena = 8.6 });
        baza.DodajFilm(new Film { ID = 11, Tytuł = "The Lord of the Rings: The Return of the King", Reżyser = "Peter Jackson", RokProdukcji = 2003, Gatunek = "Adventure", CzasTrwania = 201, Ocena = 8.9 });
        baza.DodajFilm(new Film { ID = 12, Tytuł = "Fight Club", Reżyser = "David Fincher", RokProdukcji = 1999, Gatunek = "Drama", CzasTrwania = 139, Ocena = 8.8 });
        baza.DodajFilm(new Film { ID = 13, Tytuł = "The Shawshank Redemption", Reżyser = "Frank Darabont", RokProdukcji = 1994, Gatunek = "Drama", CzasTrwania = 142, Ocena = 9.3 });
        baza.DodajFilm(new Film { ID = 14, Tytuł = "The Godfather", Reżyser = "Francis Ford Coppola", RokProdukcji = 1972, Gatunek = "Crime", CzasTrwania = 175, Ocena = 9.2 });
        baza.DodajFilm(new Film { ID = 15, Tytuł = "The Dark Knight", Reżyser = "Christopher Nolan", RokProdukcji = 2008, Gatunek = "Action", CzasTrwania = 152, Ocena = 9.0 });
        baza.DodajFilm(new Film { ID = 16, Tytuł = "Forrest Gump", Reżyser = "Robert Zemeckis", RokProdukcji = 1994, Gatunek = "Drama", CzasTrwania = 142, Ocena = 8.8 });
        baza.DodajFilm(new Film { ID = 17, Tytuł = "Inception", Reżyser = "Christopher Nolan", RokProdukcji = 2010, Gatunek = "Sci-Fi", CzasTrwania = 148, Ocena = 8.7 });
        baza.DodajFilm(new Film { ID = 18, Tytuł = "The Matrix", Reżyser = "The Wachowskis", RokProdukcji = 1999, Gatunek = "Action", CzasTrwania = 136, Ocena = 8.7 });

        // Dodanie kilku klientów
        baza.DodajKlienta(new Klient("Jan", "Kowalski", "ul. Kwiatowa 5, 30-001 Kraków", "jan.kowalski@email.com", "123456789"));
        baza.DodajKlienta(new Klient("Anna", "Nowak", "ul. Leśna 10, 50-200 Wrocław", "anna.nowak@email.com", "987654321"));
        baza.DodajKlienta(new Klient("Piotr", "Wiśniewski", "ul. Słoneczna 3, 80-001 Gdańsk", "piotr.wisniewski@email.com", "456789012"));
        baza.DodajKlienta(new Klient("Magdalena", "Dąbrowska", "ul. Miodowa 8, 20-150 Lublin", "magdalena.dabrowska@email.com", "789012345"));
        baza.DodajKlienta(new Klient("Krzysztof", "Kaczmarek", "ul. Ogrodowa 12, 60-300 Poznań", "krzysztof.kaczmarek@email.com", "234567890"));
        baza.DodajKlienta(new Klient("Monika", "Lewandowska", "ul. Słowiańska 7, 40-500 Katowice", "monika.lewandowska@email.com", "567890123"));
        baza.DodajKlienta(new Klient("Tomasz", "Adamczyk", "ul. Rycerska 15, 70-100 Szczecin", "tomasz.adamczyk@email.com", "012345678"));
        baza.DodajKlienta(new Klient("Alicja", "Kowalczyk", "ul. Krótka 9, 90-200 Łódź", "alicja.kowalczyk@email.com", "345678901"));
        baza.DodajKlienta(new Klient("Grzegorz", "Jankowski", "ul. Długa 6, 10-050 Olsztyn", "grzegorz.jankowski@email.com", "678901234"));
        baza.DodajKlienta(new Klient("Natalia", "Mazur", "ul. Zielona 20, 50-300 Wrocław", "natalia.mazur@email.com", "123450987"));
        baza.DodajKlienta(new Klient("Marcin", "Wójcik", "ul. Jasna 11, 30-100 Kraków", "marcin.wojcik@email.com", "789012345"));
        baza.DodajKlienta(new Klient("Karolina", "Kruk", "ul. Wrzosowa 14, 80-010 Gdańsk", "karolina.kruk@email.com", "345678901"));
        baza.DodajKlienta(new Klient("Dawid", "Zając", "ul. Lipowa 18, 20-250 Lublin", "dawid.zajac@email.com", "012345678"));
        baza.DodajKlienta(new Klient("Agnieszka", "Piotrowska", "ul. Malinowa 22, 60-400 Poznań", "agnieszka.piotrowska@email.com", "567890123"));
        baza.DodajKlienta(new Klient("Rafał", "Witkowski", "ul. Żeromskiego 33, 40-600 Katowice", "rafal.witkowski@email.com", "234567890"));
        baza.DodajKlienta(new Klient("Sylwia", "Sawicka", "ul. Mickiewicza 25, 70-200 Szczecin", "sylwia.sawicka@email.com", "901234567"));
        baza.DodajKlienta(new Klient("Michał", "Kowal", "ul. Parkowa 27, 90-300 Łódź", "michal.kowal@email.com", "345678901"));
        baza.DodajKlienta(new Klient("Ewa", "Kwiatkowska", "ul. Prosta 30, 10-100 Olsztyn", "ewa.kwiatkowska@email.com", "678901234"));
        baza.DodajKlienta(new Klient("Kamil", "Sobczak", "ul. Polna 40, 50-400 Wrocław", "kamil.sobczak@email.com", "123450987"));
        baza.DodajKlienta(new Klient("Joanna", "Górska", "ul. Wolności 5, 30-050 Kraków", "joanna.gorska@email.com", "789012345"));


        DodajPrzykladoweTransakcje(baza);


        // Zapis bazy danych do pliku XML
        baza.ZapiszDoPliku("bazafilmow1.xml");
        string sciezkaDoPliku = @"C:\\Users\\domin\\OneDrive\\Desktop\\najnowszepo1749\\Projekt_PO\\bazafilmow1.xml";
        baza.ZapiszDoPliku(sciezkaDoPliku);

        // Odczyt bazy danych z pliku XML
        BazaDanych wczytanaBaza = BazaDanych.OdczytajZPliku("bazafilmow1.xml");

        // Przykładowe użycie wczytanej bazy danych
        Console.WriteLine("Informacje o filmach po odczycie");
        foreach (var film in wczytanaBaza.Filmy)
        {
            film.PobierzInformacje();
            Console.WriteLine();
        }

        // Przykładowe użycie wczytanej bazy danych
        Console.WriteLine("Informacje o klientach po odczycie");
        foreach (var klient in wczytanaBaza.Klienci)
        {
            klient.PobierzInformacje();
            Console.WriteLine();
        }

        // Przykładowe użycie wczytanej bazy danych
        Console.WriteLine("Informacje o transakcjach po odczycie");
        foreach (var transakcja in wczytanaBaza.Transakcje)
        {
            transakcja.PobierzInformacje();
            Console.WriteLine($"Opłata: {transakcja.ObliczOpłatę()} zł\n");
        }

        static void DodajPrzykladoweTransakcje(BazaDanych baza)
        {
            Transakcja transakcja1 = new Transakcja
            {
                IDTransakcji = 1,
                IDFilmu = 2,
                IDKlienta = 3,
                DataWypożyczenia = DateTime.Now,
                DataZwrotu = DateTime.Now.AddDays(7)
            };

            Transakcja transakcja2 = new Transakcja
            {
                IDTransakcji = 2,
                IDFilmu = 1,
                IDKlienta = 4,
                DataWypożyczenia = DateTime.Now.AddDays(2),
                DataZwrotu = DateTime.Now.AddDays(9)
            };

            // Dodawanie transakcji do bazy danych
            baza.DodajTransakcję(transakcja1);
            baza.DodajTransakcję(transakcja2);
        }


        // Sprawdź, czy wczytana baza danych zawiera filmy, klientów i transakcje
        Console.WriteLine("Liczba filmów w bazie: " + wczytanaBaza.Filmy.Count);
        Console.WriteLine("Liczba klientów w bazie: " + wczytanaBaza.Klienci.Count);
        Console.WriteLine("Liczba transakcji w bazie: " + wczytanaBaza.Transakcje.Count);


    }
    static void Main()
    {
        Proba();
    }
}
