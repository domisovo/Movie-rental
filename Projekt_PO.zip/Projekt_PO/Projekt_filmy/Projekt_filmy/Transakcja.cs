﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Projekt_filmy
{
    public interface ITransakcjeOperacje
    {
        double ObliczOpłatę();
        abstract void PobierzInformacje();
    }

    // Abstrakcyjna klasa dla Transakcji
    public abstract class TransakcjaBase
    {
        public abstract void PobierzInformacje();
    }

    // Klasa Transakcja
    [XmlType("Transakcja")]
    public class Transakcja : TransakcjaBase, ITransakcjeOperacje
    {
        [XmlElement("IDTransakcji")]
        public int IDTransakcji { get; set; }
        [XmlElement("IDFilmu")]
        public int IDFilmu { get; set; }
        [XmlElement("IDKlienta")]
        public int IDKlienta { get; set; }
        [XmlElement("DataWypożyczenia")]
        public DateTime DataWypożyczenia { get; set; }
        [XmlElement("DataZwrotu")]
        public DateTime DataZwrotu { get; set; }

        public Transakcja() { }

        public double ObliczOpłatę()
        {
            // Zakładamy, że opłata wynosi 5.0 za dzień wypożyczenia filmu
            const double CenaZaDzien = 5.0;

            // Obliczamy różnicę w dniach między datą wypożyczenia a datą zwrotu
            TimeSpan roznicaCzasu = DataZwrotu - DataWypożyczenia;
            int dniWypozyczenia = roznicaCzasu.Days;

            // Obliczamy opłatę
            double oplata = dniWypozyczenia * CenaZaDzien;

            return oplata;
        }

        // Konstruktor z parametrami
        public Transakcja(int idTransakcji, int idFilmu, int idKlienta, DateTime dataWypożyczenia, DateTime dataZwrotu)
        {
            IDTransakcji = idTransakcji;
            IDFilmu = idFilmu;
            IDKlienta = idKlienta;
            DataWypożyczenia = dataWypożyczenia;
            DataZwrotu = dataZwrotu;
        }


        public override void PobierzInformacje()
        {
            Console.WriteLine($"IDTransakcji: {IDTransakcji}, IDFilmu: {IDFilmu}, IDKlienta: {IDKlienta}, Data wypożyczenia: {DataWypożyczenia}, Data zwrotu: {DataZwrotu}");
        }
    }

}
