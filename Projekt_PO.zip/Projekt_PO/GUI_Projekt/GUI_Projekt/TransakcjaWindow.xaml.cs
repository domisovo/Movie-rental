﻿using Projekt_filmy;
using System;
using System.Collections.ObjectModel;
using System.Windows;

namespace GUI_Projekt
{
    public partial class TransakcjaWindow : Window
    {
        private Transakcja edytowanaTransakcja;
        private BazaDanych bazaDanych;

        public TransakcjaWindow(Transakcja edytowanaTransakcja, BazaDanych bazaDanych)
        {
            InitializeComponent();
            this.edytowanaTransakcja = edytowanaTransakcja;
            this.bazaDanych = bazaDanych;
            Loaded += TransakcjaWindow_Loaded;

            UstawDaneNaKontrolkach();
        }

        private void UstawDaneNaKontrolkach()
        {
            TxtBoxIDTransakcji.Text = edytowanaTransakcja.IDTransakcji.ToString();
            TxtBoxIDFilmu.Text = edytowanaTransakcja.IDFilmu.ToString();
            TxtBoxIDKlienta.Text = edytowanaTransakcja.IDKlienta.ToString();
            DatePickerDataWypozyczenia.SelectedDate = edytowanaTransakcja.DataWypożyczenia;
            DatePickerDataZwrotu.SelectedDate = edytowanaTransakcja.DataZwrotu;
        }

        private void TransakcjaWindow_Loaded(object sender, RoutedEventArgs e)
        {
            LstTransakcja.ItemsSource = new ObservableCollection<Transakcja>(bazaDanych.Transakcje);
            LstTransakcja.DisplayMemberPath = "IDTransakcji";

            if (DatePickerDataWypozyczenia.SelectedDate == DateTime.MinValue)
            {
                DatePickerDataWypozyczenia.SelectedDate = DateTime.Now;
            }

            if (DatePickerDataZwrotu.SelectedDate == DateTime.MinValue)
            {
                DatePickerDataZwrotu.SelectedDate = DateTime.Now;
            }

            LstTransakcja.ItemsSource = new ObservableCollection<Transakcja>(bazaDanych.Transakcje);

            LstTransakcja.SelectionChanged += ListTransakcja_SelectionChanged;

        }

        private void BtnZatwierdz_Click(object sender, RoutedEventArgs e)
        {
            if (SprawdzPoprawnoscDanych())
            {
                AktualizujDaneTransakcji();
                MessageBox.Show("Transakcja została zaktualizowana.");
                Close();
            }
        }

        private bool SprawdzPoprawnoscDanych()
        {
            if (string.IsNullOrWhiteSpace(TxtBoxIDTransakcji.Text) ||
                string.IsNullOrWhiteSpace(TxtBoxIDFilmu.Text) ||
                string.IsNullOrWhiteSpace(TxtBoxIDKlienta.Text) ||
                DatePickerDataWypozyczenia.SelectedDate == null ||
                DatePickerDataZwrotu.SelectedDate == null)
            {
                MessageBox.Show("Wypełnij wszystkie pola przed zatwierdzeniem.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!int.TryParse(TxtBoxIDTransakcji.Text, out int idTransakcji)
                || !int.TryParse(TxtBoxIDFilmu.Text, out _)
                || !int.TryParse(TxtBoxIDKlienta.Text, out _))
            {
                MessageBox.Show("Wprowadź poprawne dane liczbowe.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (idTransakcji == 0 && DatePickerDataWypozyczenia.SelectedDate == DatePickerDataZwrotu.SelectedDate)
            {
                MessageBox.Show("ID transakcji nie może być równe 0, a daty wypożyczenia i zwrotu nie mogą być takie same.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            return true;
        }

        private void AktualizujDaneTransakcji()
        {
            edytowanaTransakcja.IDTransakcji = Convert.ToInt32(TxtBoxIDTransakcji.Text);
            edytowanaTransakcja.IDFilmu = Convert.ToInt32(TxtBoxIDFilmu.Text);
            edytowanaTransakcja.IDKlienta = Convert.ToInt32(TxtBoxIDKlienta.Text);
            edytowanaTransakcja.DataWypożyczenia = DatePickerDataWypozyczenia.SelectedDate ?? DateTime.MinValue;
            edytowanaTransakcja.DataZwrotu = DatePickerDataZwrotu.SelectedDate ?? DateTime.MinValue;
        }

        private void BtnAnulujTransakcje_Click(object sender, RoutedEventArgs e)
        {
            if (LstTransakcja.SelectedItem == null)
            {
                MessageBox.Show("Proszę zaznaczyć transakcję do usunięcia.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            Transakcja wybranaTransakcja = (Transakcja)LstTransakcja.SelectedItem;

            MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz usunąć transakcję o ID {wybranaTransakcja.IDTransakcji}?", "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                bazaDanych.Transakcje.Remove(wybranaTransakcja);

                string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\DoObrony\\Projekt_PO\\bazafilmow1.xml";
                bazaDanych.ZapiszDoPliku(sciezkaDoPliku);

                LstTransakcja.ItemsSource = new ObservableCollection<Transakcja>(bazaDanych.Transakcje);

                MessageBox.Show($"Transakcja o ID {wybranaTransakcja.IDTransakcji} została pomyślnie usunięta.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            Close();
        }


        private void ListTransakcja_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (LstTransakcja.SelectedItem != null)
            {
                Transakcja wybranaTransakcja = (Transakcja)LstTransakcja.SelectedItem;
            }
        }

        private void BtnZatwierdz1_Click(object sender, RoutedEventArgs e)
        {
            if (SprawdzPoprawnoscDanych())
            {
                int idTransakcji = int.Parse(TxtBoxIDTransakcji.Text);

                // Sprawdź, czy istnieje już transakcja o podanym ID
                if (bazaDanych.Transakcje.Any(t => t.IDTransakcji == idTransakcji))
                {
                    MessageBox.Show($"Transakcja o ID {idTransakcji} już istnieje. Wprowadź unikalne ID.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                int idFilmu = int.Parse(TxtBoxIDFilmu.Text);
                int idKlienta = int.Parse(TxtBoxIDKlienta.Text);
                DateTime dataWypozyczenia = DatePickerDataWypozyczenia.SelectedDate ?? DateTime.MinValue;
                DateTime dataZwrotu = DatePickerDataZwrotu.SelectedDate ?? DateTime.MinValue;

                Transakcja nowaTransakcja = new Transakcja
                {
                    IDTransakcji = idTransakcji,
                    IDFilmu = idFilmu,
                    IDKlienta = idKlienta,
                    DataWypożyczenia = dataWypozyczenia,
                    DataZwrotu = dataZwrotu
                };

                MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz zatwierdzić nową transakcję o ID {idTransakcji}?", "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    bazaDanych.DodajTransakcję(nowaTransakcja);

                    string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\najnowszepo1749\\Projekt_PO\\bazafilmow1.xml";
                    bazaDanych.ZapiszDoPliku(sciezkaDoPliku);

                    LstTransakcja.ItemsSource = new ObservableCollection<Transakcja>(bazaDanych.Transakcje);

                    MessageBox.Show($"Transakcja o ID {idTransakcji} została pomyślnie zatwierdzona.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);

                    Close();
                }
            }
        }

        private void BtnObliczOpłate_Click(object sender, RoutedEventArgs e)
        {
            DateTime dataWypozyczenia = DatePickerDataWypozyczenia.SelectedDate ?? DateTime.MinValue;
            DateTime dataZwrotu = DatePickerDataZwrotu.SelectedDate ?? DateTime.MinValue;

            if (dataWypozyczenia == DateTime.MinValue || dataZwrotu == DateTime.MinValue)
            {
                MessageBox.Show("Wprowadź daty wypożyczenia i zwrotu.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            double oplata = ObliczOpłatę(dataWypozyczenia, dataZwrotu);

            TxtBoxOplata.Text = oplata.ToString("C");
        }

        private void TxtBoxOplata_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            DateTime dataWypozyczenia = DatePickerDataWypozyczenia.SelectedDate ?? DateTime.MinValue;
            DateTime dataZwrotu = DatePickerDataZwrotu.SelectedDate ?? DateTime.MinValue;

            if (dataWypozyczenia == DateTime.MinValue || dataZwrotu == DateTime.MinValue)
            {
                MessageBox.Show("Wprowadź daty wypożyczenia i zwrotu.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            double oplata = ObliczOpłatę(dataWypozyczenia, dataZwrotu);

            TxtBoxOplata.Text = oplata.ToString("C");
        }

        private double ObliczOpłatę(DateTime dataWypozyczenia, DateTime dataZwrotu)
        {
            const double CenaZaDzien = 5.0;
            TimeSpan roznicaCzasu = dataZwrotu - dataWypozyczenia;
            int dniWypozyczenia = roznicaCzasu.Days;

            double oplata = 5.0 + dniWypozyczenia * CenaZaDzien;

            return oplata;
        }

        private void BtnWyjdz_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Czy na pewno chcesz Wyjść?", "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                DialogResult = false;
            }
        }
    }
}
