﻿using Projekt_filmy;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace GUI_Projekt
{
    public partial class DodajFilmWindow : Window
    {
        Film nowyFilm;
        public bool DodanoFilm { get; private set; }

        public DodajFilmWindow()
        {
            InitializeComponent();
            nowyFilm = new Film();
            Closed += DodajFilmWindow_Closed;
        }

        private void BtnDodajFilm_Click(object sender, RoutedEventArgs e)
        {
            string tytul = TxtTytul.Text;
            string rezyser = TxtRezyser.Text;
            string rokProdukcjiStr = TxtRokProdukcji.Text;
            string gatunek = TxtGatunek.Text;
            string czasTrwaniaStr = TxtCzasTrwania.Text;
            string ocenaStr = TxtOcena.Text;

            if (string.IsNullOrEmpty(tytul) || string.IsNullOrEmpty(rezyser) || string.IsNullOrEmpty(gatunek))
            {
                MessageBox.Show("Uzupełnij wymagane pola przed dodaniem filmu.", "Puste pola", MessageBoxButton.OK, MessageBoxImage.Warning);
                DialogResult = false;
                return;
            }

            if (!int.TryParse(rokProdukcjiStr, out int rokProdukcji) || !int.TryParse(czasTrwaniaStr, out int czasTrwania) || !double.TryParse(ocenaStr, out double ocena))
            {
                MessageBox.Show("Wprowadź poprawne dane liczbowe.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                DialogResult = false;
                return;
            }

            nowyFilm.Tytuł = tytul;
            nowyFilm.Reżyser = rezyser;
            nowyFilm.RokProdukcji = rokProdukcji;
            nowyFilm.Gatunek = gatunek;
            nowyFilm.CzasTrwania = czasTrwania;
            nowyFilm.Ocena = ocena;
            nowyFilm.Dostępny = ChkDostepny.IsChecked ?? false;

            string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\DoObrony\\Projekt_PO\\bazafilmow1.xml";
            BazaDanych bazaDanych = BazaDanych.OdczytajZPliku(sciezkaDoPliku);
            bazaDanych.DodajFilm(nowyFilm);
            bazaDanych.ZapiszDoPliku(sciezkaDoPliku);

            DodanoFilm = true;
            DialogResult = true;
        }

        private void BtnAnulujFilm_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Czy na pewno chcesz anulować dodawanie filmu?", "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                DialogResult = false;
            }
        }

        public void DodajFilmWindow_Closed(object sender, EventArgs e)
        {
            if (DodanoFilm)
            {
                MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
                if (mainWindow != null)
                {
                    mainWindow.RefreshPage();
                }
            }
        }
    }
}
