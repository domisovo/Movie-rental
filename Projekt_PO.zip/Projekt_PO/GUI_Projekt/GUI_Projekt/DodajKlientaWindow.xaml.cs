﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Globalization;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Projekt_filmy;

namespace GUI_Projekt
{
    public partial class DodajKlientaWindow : Window
    {
        Klient klient;

        public bool DodanoKlienta { get; private set; }
        public Klient NowyKlient { get; private set; }

        public DodajKlientaWindow()
        {
            InitializeComponent();
        }

        public DodajKlientaWindow(Klient k) : this()
        {
            if (k != null)
            {
                TxtImie.Text = k.Imię;
                TxtNazwisko.Text = k.Nazwisko;
                TxtTelefon.Text = k.NumerTelefonu;
                TxtMail.Text = k.Email;
                TxtAdres.Text = k.Adres;
                DodanoKlienta = true;
            }
            else
            {
                DodanoKlienta = false;
            }
        }

        private void Button_Click_zatwierdz(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;
            bool res = false;
            Klient k = new Klient();

            if (clickedButton != null)
            {
                if (!string.IsNullOrEmpty(TxtImie.Text) ||
                    !string.IsNullOrEmpty(TxtNazwisko.Text) ||
                    !string.IsNullOrEmpty(TxtTelefon.Text) ||
                    !string.IsNullOrEmpty(TxtAdres.Text) ||
                    !string.IsNullOrEmpty(TxtMail.Text) && k is not null)
                {
                    k.Imię = TxtImie.Text;
                    k.Nazwisko = TxtNazwisko.Text;
                    k.NumerTelefonu = TxtTelefon.Text;
                    k.Email = TxtMail.Text;
                    k.Adres = TxtAdres.Text;

                    MessageBoxResult result = MessageBox.Show("Czy na pewno chcesz dodać tego klienta?", "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

                    if (result == MessageBoxResult.Yes)
                    {
                        string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\DoObrony\\Projekt_PO\\bazafilmow1.xml";
                        BazaDanych bazaDanych = BazaDanych.OdczytajZPliku(sciezkaDoPliku);
                        bazaDanych.DodajKlienta(k);
                        bazaDanych.ZapiszDoPliku(sciezkaDoPliku);

                        NowyKlient = k;
                        res = true;
                    }
                    else
                    {
                        res = false;
                    }
                }
                else
                {
                    MessageBox.Show("Uzupełnij wszystkie pola przed zatwierdzeniem.", "Brak danych", MessageBoxButton.OK, MessageBoxImage.Warning);
                    res = false;
                }

                DialogResult = res;
            }
        }

        private void Button_Click_anuluj(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Czy na pewno chcesz anulować dodawanie klienta?", "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                DialogResult = false;
            }
        }
    }
}
