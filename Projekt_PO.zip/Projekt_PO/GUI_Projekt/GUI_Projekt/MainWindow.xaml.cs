﻿using Projekt_filmy;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GUI_Projekt
{
    public partial class MainWindow : Window
    {
        private BazaDanych bazaDanych;


        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;

            string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\DoObrony\\Projekt_PO\\bazafilmow1.xml";
            this.bazaDanych = BazaDanych.OdczytajZPliku(sciezkaDoPliku);
        }


        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\DoObrony\\Projekt_PO\\bazafilmow1.xml";
            this.bazaDanych = BazaDanych.OdczytajZPliku(sciezkaDoPliku);

            LstFilmy.ItemsSource = new ObservableCollection<Film>(bazaDanych.Filmy);

            LstKlienci.ItemsSource = bazaDanych.Klienci;

            LstKlienci.ItemTemplate = new DataTemplate(typeof(Klient));

            FrameworkElementFactory stackPanelFactory = new FrameworkElementFactory(typeof(StackPanel));
            stackPanelFactory.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);

            FrameworkElementFactory klientTextFactory = new FrameworkElementFactory(typeof(TextBlock));
            klientTextFactory.SetBinding(TextBlock.TextProperty, new Binding());

            stackPanelFactory.AppendChild(klientTextFactory);

            LstKlienci.ItemTemplate.VisualTree = stackPanelFactory;

            bazaDanych = BazaDanych.OdczytajZPliku(sciezkaDoPliku);

            LstFilmy.ItemsSource = bazaDanych.Filmy;

            LstFilmy.ItemTemplate = new DataTemplate(typeof(Film));

            FrameworkElementFactory filmTextFactory = new FrameworkElementFactory(typeof(TextBlock));
            filmTextFactory.SetBinding(TextBlock.TextProperty, new Binding());

            LstFilmy.ItemTemplate.VisualTree = filmTextFactory;
        }


        private void BtnDodajKlient_Click(object sender, RoutedEventArgs e)
        {
            Klient k = new Klient();
            DodajKlientaWindow noweOkno = new DodajKlientaWindow();
            noweOkno.ShowDialog();

            if (noweOkno.DodanoKlienta && bazaDanych is not null)
            {
                bazaDanych.DodajKlienta(k);
            }
        }


        private void BtnUsunKlienta_Click(object sender, RoutedEventArgs e)
        {
            if (LstKlienci.SelectedItem != null && bazaDanych != null)
            {
                Klient wybranyKlient = (Klient)LstKlienci.SelectedItem;

                bazaDanych.UsuńKlienta(wybranyKlient.ID);

                string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\DoObrony\\Projekt_PO\\bazafilmow1.xml";
                bazaDanych.ZapiszDoPliku(sciezkaDoPliku);

                LstKlienci.ItemsSource = new ObservableCollection<Klient>(bazaDanych.Klienci);

                MessageBox.Show($"Klient {wybranyKlient.Imię} {wybranyKlient.Nazwisko} został pomyślnie usunięty.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        public void RefreshPage()
        {
            LstFilmy.ItemsSource = new ObservableCollection<Film>(bazaDanych.Filmy);
            LstKlienci.ItemsSource = new ObservableCollection<Klient>(bazaDanych.Klienci);
        }

        private void BtnDodajFilm_Click(object sender, RoutedEventArgs e)
        {
            DodajFilmWindow noweOkno = new DodajFilmWindow();
            noweOkno.ShowDialog();

            if (noweOkno.DodanoFilm && bazaDanych is not null)
            {
                LstFilmy.ItemsSource = new ObservableCollection<Film>(bazaDanych.Filmy);
            }
        }
        private void BtnUsunFilm_Click(object sender, RoutedEventArgs e)
        {
            if (LstFilmy.SelectedItem != null && bazaDanych != null)
            {
                Film wybranyFilm = (Film)LstFilmy.SelectedItem;

                MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz usunąć film {wybranyFilm.Tytuł}?", "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    bazaDanych.UsuńFilm(wybranyFilm.ID);

                    string sciezkaDoPliku = "C:\\Users\\domin\\OneDrive\\Desktop\\DoObrony\\Projekt_PO\\bazafilmow1.xml";
                    bazaDanych.ZapiszDoPliku(sciezkaDoPliku);

                    LstFilmy.ItemsSource = new ObservableCollection<Film>(bazaDanych.Filmy);

                    MessageBox.Show($"Film {wybranyFilm.Tytuł} został pomyślnie usunięty.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }


        private void MenuOtworz_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.InitialDirectory = Environment.CurrentDirectory;
            dlg.Filter = "xml files (*.zml)|*.xml"; ;
            Nullable<bool> result = dlg.ShowDialog();
            if (result == true)
            {
                string filename = dlg.FileName;
                bazaDanych = BazaDanych.OdczytajZPliku(filename);
                if (bazaDanych is not null)
                {
                    LstKlienci.ItemsSource = new ObservableCollection<Klient>(bazaDanych.Klienci);
                }
            }
        }
        private void MenuZapisz_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            Nullable<bool> result = dlg.ShowDialog();
            if (result == true)
            {
                string filename = dlg.FileName;
                bazaDanych.ZapiszDoPliku(filename);
            }
        }
        private void MenuZakoncz_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void LstKlienci_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

            LstKlienci.ItemsSource = bazaDanych.Klienci;
            Klient wybranyKlient = LstKlienci.SelectedItem as Klient;

        }

        private void LstFilmy_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LstFilmy.SelectedItem != null)
            {
                Film wybranyFilm = (Film)LstFilmy.SelectedItem;
            }
        }

        private void BtnDodajTransakcje_Click(object sender, RoutedEventArgs e)
        {
            Transakcja nowaTransakcja = UtworzNowaTransakcje();

            if (bazaDanych is not null)
            {
                TransakcjaWindow transakcjaWindow = new TransakcjaWindow(nowaTransakcja, bazaDanych);

                transakcjaWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Błąd: Brak dostępu do bazy danych.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private Transakcja UtworzNowaTransakcje()
        {
            Transakcja nowaTransakcja = new Transakcja();
            return nowaTransakcja;
        }

    }
}
